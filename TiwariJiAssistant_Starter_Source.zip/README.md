# Tiwari Ji Assistant — starter Android project

Package: `com.tiwari.assistant`  
Language: Java + XML  
Minimum Android: 6.0 (API 23)

## Current working starter features
- Hindi speech input using Android speech recognition (requires microphone permission and a device speech-recognition service).
- Hindi text-to-speech reply (availability depends on installed TTS voice).
- Typed commands.
- Local notes stored in app-private SharedPreferences.
- Time query.

## Open and build
1. Install Android Studio (Ladybug or newer) and Android SDK 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press Run. Android Studio will build and install the debug app.

## Important next development phase
This is a real starter source project, not a finished Jarvis-level assistant and not a prebuilt APK.
The cloud AI service is intentionally not connected yet. Do not put an AI provider secret/API key inside the Android app.
Next phases: secure backend proxy + AI chat, reliable reminders/notifications, calendar/email connectors with explicit account consent, and opt-in foreground wake-word mode. Android does not allow unrestricted always-listening/background device control; permissions and user-visible foreground services are required.
