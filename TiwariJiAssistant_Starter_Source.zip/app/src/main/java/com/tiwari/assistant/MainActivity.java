package com.tiwari.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQ_SPEECH = 100;
    private static final int REQ_AUDIO_PERMISSION = 101;
    private EditText commandInput;
    private TextView conversation;
    private TextToSpeech tts;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        commandInput = findViewById(R.id.commandInput);
        conversation = findViewById(R.id.conversation);
        Button run = findViewById(R.id.runButton);
        Button speak = findViewById(R.id.speakButton);
        tts = new TextToSpeech(this, this);
        prefs = getSharedPreferences("tiwari_notes", MODE_PRIVATE);

        run.setOnClickListener(v -> handleCommand(commandInput.getText().toString().trim()));
        speak.setOnClickListener(v -> startVoiceInput());
        append("Tiwari Ji", "नमस्ते! मैं आपका personal assistant हूँ। आप बोलकर या लिखकर आदेश दे सकते हैं।");
    }

    private void startVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO_PERMISSION);
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Tiwari Ji को अपना आदेश बताइए");
        try { startActivityForResult(intent, REQ_SPEECH); }
        catch (Exception e) { Toast.makeText(this, "इस डिवाइस पर speech recognition उपलब्ध नहीं है।", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                commandInput.setText(results.get(0));
                handleCommand(results.get(0));
            }
        }
    }

    private void handleCommand(String raw) {
        if (raw == null || raw.trim().isEmpty()) return;
        String cmd = raw.trim();
        append("आप", cmd);
        String lower = cmd.toLowerCase(Locale.ROOT);
        String reply;
        if (lower.contains("समय") || lower.contains("time")) {
            reply = "अभी समय है " + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date());
        } else if (lower.startsWith("नोट") || lower.startsWith("note") || lower.contains("याद रखना")) {
            String note = cmd.replaceFirst("(?i)^(नोट|note)[: ]*", "").replace("याद रखना", "").trim();
            if (note.isEmpty()) note = cmd;
            String old = prefs.getString("notes", "");
            String updated = old.isEmpty() ? note : old + "\n• " + note;
            prefs.edit().putString("notes", updated).apply();
            reply = "ठीक है, मैंने यह नोट इस डिवाइस में सेव कर लिया: " + note;
        } else if (lower.contains("मेरे नोट") || lower.contains("show notes") || lower.contains("notes dikhao")) {
            String notes = prefs.getString("notes", "");
            reply = notes.isEmpty() ? "अभी कोई नोट सेव नहीं है।" : "आपके सेव किए नोट:\n" + notes;
        } else if (lower.contains("नमस्ते") || lower.contains("hello") || lower.contains("hi")) {
            reply = "नमस्ते! बताइए, मैं आपकी क्या मदद करूँ?";
        } else {
            reply = "मैंने आपका आदेश समझा: "" + cmd + ""। AI cloud connection अभी configure नहीं है; फिलहाल समय और notes जैसे basic commands काम करते हैं।";
        }
        append("Tiwari Ji", reply);
        speak(reply);
        commandInput.setText("");
    }

    private void append(String who, String message) {
        conversation.append("\n\n" + who + ": " + message);
    }

    private void speak(String message) {
        if (tts != null) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "tiwari_reply");
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVoiceInput();
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
